import os
import socket
import time

from mininet.net import Mininet
from mininet.cli import CLI
from mininet.node import Controller, RemoteController
from mininet.log import setLogLevel, info

def is_controller_running(ip="127.0.0.1", port=6633):
    """Failsafe check: Tests if POX is actively listening on its standard port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((ip, port))
            return True
        except (socket.timeout, ConnectionRefusedError):
            return False

def topology():
    # Check for POX Controller availability
    info("*** Checking Controller Status...\n")
    if is_controller_running():
        info("  [+] POX Controller detected active on port 6633. Using POX!\n")
        chosen_controller = RemoteController
        controller_args = {'name': 'c0', 'ip': '127.0.0.1', 'port': 6633}
    else:
        info("  [!] POX Controller NOT running. Activating Failsafe: Standard Controller.\n")
        chosen_controller = Controller
        controller_args = {'name': 'c0' }

    net = Mininet(
        controller=chosen_controller,
    )

    info("*** Creating Nodes\n")

    # Dynamic Controller Initialization
    c0 = net.addController(**controller_args)

   # Guest WiFi Access Point (VULNERABLE)
    ap1 = net.addSwitch('ap1')

    # The Layer 3 Router
    home_router = net.addHost('r1')
    


    # Switch (internal LAN)
    s1 = net.addSwitch('s1')

    # Attacker (Home PC via Static Wireless)
    h1 = net.addHost(
        'h1',
        ip='192.168.10.10/24'
    )

    # Mobile Phone
    m1 = net.addHost(
        'm1',
        ip='192.168.10.20/24',
    )

    # Internal Server (target - Wired Host)
    h2 = net.addHost(
        'h2',
        ip='192.168.20.20/24'
    )

    # Internal PC (Wired Host)
    h3 = net.addHost(
        'h3',
        ip='192.168.20.30/24'
    )

    info("*** Configuring WiFi nodes ***\n")

    info("*** Creating links ***\n")
    # linking the Router and Wifi (AP) together
    net.addLink(home_router, ap1)

    # WiFi links 
    net.addLink(h1, ap1)
    net.addLink(m1, ap1)
  
    #Internal LAN links 
    net.addLink(home_router, s1)
    net.addLink(h2, s1)
    net.addLink(h3, s1)


    info("\n********************* Starting network *********************\n")
    net.build()
    c0.start()
    s1.start([c0])
    ap1.start([c0])

    # Force Open vSwitch to act as a normal, standalone Layer-2 wireless bridge.
    # This stops the controller from blackholing packets between r1 and the stations.
    ap1.cmd('ovs-vsctl set-bridge ap1 fail-mode=standalone')
    ap1.cmd('ovs-ofctl del-flows ap1')


    # Insert new configuration here.
    # adding interfaces to the wireless-home-router

    
  

    info("\n ******************   Running CLI  *************************\n")
    CLI(net)

    info("\n *****************  Stopping network ***********************\n")
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    topology()
