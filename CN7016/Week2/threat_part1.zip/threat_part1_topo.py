
import os
import socket
from mininet.net import Mininet
from mininet.cli import CLI
from mininet.node import Controller, RemoteController
from mininet.log import setLogLevel, info


def is_controller_running(ip="127.0.0.1", port=6633):
    """Failsafe check: Tests if POX is actively listening on its standard port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((ip, port))
            return True
        except (socket.timeout, ConnectionRefusedError):
            return False

def topology():
    # Check for POX Controller availability
    info("*** Checking Controller Status...\n")
    if is_controller_running():
        info("  [+] POX Controller detected active on port 6633. Using POX!\n")
        chosen_controller = RemoteController
        controller_args = {'name': 'c0', 'ip': '127.0.0.1', 'port': 6633}
    else:
        info("  [!] POX Controller NOT running. Activating Failsafe: Standard Controller.\n")
        chosen_controller = Controller
        controller_args = {'name': 'c0'}

    net = Mininet(
        controller=chosen_controller,
    )

    info("*** Creating Nodes\n")

    # Dynamic Controller Initialization
    c0 = net.addController(**controller_args)

    # Guest WiFi Access Point (VULNERABLE)
    home_router = net.addSwitch('ap1')

    # Switch (internal LAN)
    s1 = net.addSwitch('s1')

    # Attacker (Home PC via Static Wireless)
    h1 = net.addHost(
        'h1',
        ip='192.168.0.10/24'
    )

    # Mobile Phone
    m1 = net.addHost(
        'm1',
        ip='192.168.0.40/24',
    )

    # Internal Server (target - Wired Host)
    h2 = net.addHost(
        'h2',
        ip='192.168.0.20/24'
    )

    # Internal PC (Wired Host)
    h3 = net.addHost(
        'h3',
        ip='192.168.0.30/24'
    )

    info("*** Configuring Network nodes\n")

    info("*** Creating links\n")
    net.addLink(h1, home_router)
    net.addLink(m1, home_router)
    net.addLink(home_router, s1)
    net.addLink(h2, s1)
    net.addLink(h3, s1)



    info("*** Starting network\n")
    net.build()
    c0.start()
    home_router.start([c0])
    s1.start([c0])

    info("*** Running CLI\n")
    CLI(net)

    info("*** Stopping network\n")
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    topology()
